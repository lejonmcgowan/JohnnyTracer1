//
// Created by lejonmcgowan on 4/14/16.
//

#include "Box.h"

Box::Box(float legnth, float width, float depth)
{

}

bool Box::hit(const Ray& ray, HitData& hitData)
{
    return false;
}

bool Box::hit(const Ray& ray, float& t)
{
    return false;
}