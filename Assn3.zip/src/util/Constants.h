//
// Created by lejonmcgowan on 4/7/16.
//

#ifndef RAYTRACER473_CONSTANTS_H
#define RAYTRACER473_CONSTANTS_H

#include <Eigen/Dense>

//#define DOUBLE 0
//
//#ifdef DOUBLE
//#define Eigen::Vector3f Eigen::Vector3d
//#endif

class Constants
{
public:
    static float EPSILON;
};


#endif //RAYTRACER473_CONSTANTS_H
