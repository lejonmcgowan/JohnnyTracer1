//
// Created by lejonmcgowan on 4/6/16.
//

#ifndef RAYTRACER473_POVOBJECT_H
#define RAYTRACER473_POVOBJECT_H

#endif //RAYTRACER473_POVOBJECT_H
