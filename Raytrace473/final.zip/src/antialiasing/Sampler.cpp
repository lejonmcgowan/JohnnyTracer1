//
// Created by lejonmcgowan on 5/15/16.
//

#include "Sampler.h"

int Sampler::NUM_SETS = 83;