//
// Created by lejonmcgowan on 4/7/16.
//

#include "Constants.h"

float Constants::EPSILON = 0.0001f;

float Constants::PI = 3.14159265358979323846;
