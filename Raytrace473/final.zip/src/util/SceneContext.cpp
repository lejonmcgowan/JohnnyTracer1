//
// Created by lejonmcgowan on 4/12/16.
//

#include "SceneContext.h"

Eigen::Vector2i SceneContext::windowDims = Eigen::Vector2i(-1,-1);
Color SceneContext::backgroundColor = Color();
float SceneContext::aspect = 0;
int SceneContext::numSamples = 25;
int SceneContext::numBounces = 5;

bool SceneContext::octreeAcceleration = false;

bool SceneContext::bvhAcceleration = true;

int SceneContext::octreeLevel = 5;

bool SceneContext::shadows = true;